"""
LLM-based inference for MACOS (Multi-Agent Compute OS).
Loads a GRPO-trained LLM and uses it to make resource governance decisions.

Usage:
  # Run demo with trained model
  python llm_inference.py --model macos-llm-grpo --mode demo

  # Benchmark LLM vs heuristic
  python llm_inference.py --model macos-llm-grpo --mode benchmark

  # What-if adversarial analysis
  python llm_inference.py --model macos-llm-grpo --mode whatif

  # Use base model (no training) for comparison
  python llm_inference.py --model unsloth/Qwen2.5-1.5B-Instruct --mode demo
"""

import os
import json
import argparse
import numpy as np
from typing import Optional

from env.core import AdaptiveOSEnv
from env.models import Action, Observation
from env.auditor import AuditorAgent
from env.text_wrapper import (
    SYSTEM_PROMPT,
    observation_to_text,
    parse_llm_response,
)

MAX_STEPS = 30

# Global model cache
_LLM_MODEL = None
_LLM_TOKENIZER = None


def load_llm(model_path: str):
    """Load the trained LLM. Caches globally. Supports LoRA adapters."""
    global _LLM_MODEL, _LLM_TOKENIZER

    if _LLM_MODEL is not None:
        return _LLM_MODEL, _LLM_TOKENIZER

    print(f"Loading LLM from {model_path}...")
    
    # Check if this is a LoRA adapter (has adapter_config.json)
    is_lora = os.path.exists(os.path.join(model_path, "adapter_config.json"))
    
    if is_lora:
        print("Detected LoRA adapter. Loading base model + adapter...")
        # Load LoRA adapter with base model
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            from peft import PeftModel
            import torch
            
            # Determine base model from adapter config
            import json
            with open(os.path.join(model_path, "adapter_config.json")) as f:
                adapter_config = json.load(f)
            base_model_name = adapter_config.get("base_model_name_or_path", "Qwen/Qwen2.5-1.5B-Instruct")
            
            # Unsloth 4-bit models can't load without bitsandbytes+GPU.
            # Fall back to the standard HF model for CPU inference.
            QUANTIZED_PREFIXES = ("unsloth/", "bnb-4bit", "gptq", "awq")
            if any(p in base_model_name.lower() for p in QUANTIZED_PREFIXES):
                base_model_name = "Qwen/Qwen2.5-1.5B-Instruct"
                print(f"  Quantized base detected — using CPU-friendly: {base_model_name}")
            else:
                print(f"  Base model: {base_model_name}")

            tokenizer = AutoTokenizer.from_pretrained(model_path)
            base_model = AutoModelForCausalLM.from_pretrained(
                base_model_name,
                dtype=torch.float32,
                device_map="cpu",
            )
            model = PeftModel.from_pretrained(base_model, model_path)
            model.eval()
            print("Loaded with PEFT (LoRA adapter)")
        except Exception as e:
            print(f"Failed to load LoRA adapter: {e}")
            print("Trying as full model...")
            is_lora = False

    if not is_lora:
        # Try Unsloth first
        try:
            from unsloth import FastLanguageModel
            model, tokenizer = FastLanguageModel.from_pretrained(
                model_path,
                max_seq_length=2048,
                load_in_4bit=True,
                dtype=None,
            )
            FastLanguageModel.for_inference(model)
            print("Loaded with Unsloth (inference mode)")
        except ImportError:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            tokenizer = AutoTokenizer.from_pretrained(model_path)
            model = AutoModelForCausalLM.from_pretrained(
                model_path,
                torch_dtype="auto",
                device_map="auto",
            )
            model.eval()
            print("Loaded with transformers")

    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    _LLM_MODEL = model
    _LLM_TOKENIZER = tokenizer
    print("LLM ready.\n")
    return model, tokenizer


def llm_generate(model, tokenizer, obs: Observation, show_reasoning: bool = False) -> tuple:
    """
    Generate an action from the LLM given an observation.
    Returns (Action, raw_text).
    """
    import torch

    obs_text = observation_to_text(obs)
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": obs_text},
    ]

    input_text = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    inputs = tokenizer(input_text, return_tensors="pt").to(model.device)

    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=150,  # 🔥 Reduced from 400 (3x faster on CPU)
            temperature=0.3,
            top_p=0.9,
            do_sample=True,
            pad_token_id=tokenizer.pad_token_id,
        )

    # Decode only new tokens
    new_tokens = outputs[0][inputs["input_ids"].shape[1]:]
    raw_text = tokenizer.decode(new_tokens, skip_special_tokens=True)

    if show_reasoning:
        print(f"    LLM Output: {raw_text[:300]}{'...' if len(raw_text) > 300 else ''}")

    action = parse_llm_response(raw_text)
    return action, raw_text


def llm_decide_action(obs: Observation, model=None, tokenizer=None) -> Action:
    """Convenience wrapper: get action from LLM."""
    if model is None or tokenizer is None:
        model, tokenizer = _LLM_MODEL, _LLM_TOKENIZER
    if model is None:
        raise RuntimeError("No LLM loaded. Call load_llm() first.")
    action, _ = llm_generate(model, tokenizer, obs)
    return action


# ============================================================
# EPISODE RUNNER
# ============================================================

def run_llm_episode(task: str, model, tokenizer,
                    show_reasoning: bool = True, show_auditor: bool = True) -> dict:
    """Run a full episode using the LLM agent."""
    env = AdaptiveOSEnv(task=task)
    auditor = AuditorAgent()
    obs = env.reset()

    total_cost = 0
    total_reward = 0
    rewards = []
    cpu_history = []
    queue_history = []

    action_counts = {
        "SCHEDULE": 0, "KILL": 0, "PRIORITIZE": 0,
        "THROTTLE": 0, "DELAY": 0, "REALLOCATE": 0,
    }
    total_violations = {"sla_violations": 0, "starvation_count": 0, "unfair_allocations": 0}
    reasoning_samples = []

    print(f"\n{'='*80}")
    print(f"LLM AGENT - Task: {task.upper()}")
    print(f"{'='*80}")
    print(f"⏳ Running {MAX_STEPS} steps (this takes ~15-30 sec per step on CPU)...\n")

    for step in range(MAX_STEPS):
        # Show progress indicator
        if step % 5 == 0 and step > 0:
            print(f"  ⏳ Progress: {step}/{MAX_STEPS} steps completed...")
        
        # Auditor analysis
        if show_auditor:
            anomalies = auditor.detect_anomalies(obs)

        # LLM decides
        action, raw_text = llm_generate(
            model, tokenizer, obs, show_reasoning=(show_reasoning and step % 5 == 0)
        )
        action_counts[action.action_type] = action_counts.get(action.action_type, 0) + 1

        # Save reasoning sample
        if step < 5 or step % 10 == 0:
            reasoning_samples.append({
                "step": step,
                "cpu": obs.cpu_usage,
                "queue": obs.queue_length,
                "action": action.action_type,
                "target": action.target_pid,
                "reasoning": raw_text[:200],
            })

        # Step environment
        obs, reward, done, info = env.step(action)

        total_cost += obs.cost
        total_reward += reward.value
        rewards.append(reward.value)
        cpu_history.append(obs.cpu_usage)
        queue_history.append(obs.queue_length)

        for key in total_violations:
            total_violations[key] += obs.violations.get(key, 0)

        # Periodic logging
        if step % 10 == 0 or step == MAX_STEPS - 1:
            print(f"  [Step {step:02d}] action={action.action_type:<12} "
                  f"target={action.target_pid or '-':<4} "
                  f"reward={reward.value:+.3f} cpu={obs.cpu_usage:5.1f}% "
                  f"queue={obs.queue_length:2d}")

        if done:
            break

    # --- Metrics ---
    avg_cpu = np.mean(cpu_history) if cpu_history else 0
    total_actions = sum(action_counts.values())
    soft_actions = action_counts["THROTTLE"] + action_counts["DELAY"] + action_counts["REALLOCATE"]
    kill_rate = action_counts["KILL"] / max(total_actions, 1)
    soft_pct = soft_actions / max(total_actions, 1) * 100

    print(f"\n{'='*80}")
    print("LLM AGENT RESULTS")
    print(f"{'='*80}")
    print(f"  Total Cost:      ${total_cost:.2f}")
    print(f"  Avg Reward:      {total_reward/MAX_STEPS:+.3f}")
    print(f"  Avg CPU:         {avg_cpu:.1f}%")
    print(f"  SLA Violations:  {total_violations['sla_violations']}")
    print(f"  Starvation:      {total_violations['starvation_count']}")
    print(f"  Kill Rate:       {kill_rate*100:.1f}%")
    print(f"  Soft Actions:    {soft_pct:.1f}%")
    print(f"\n  Action Distribution:")
    for act, count in sorted(action_counts.items(), key=lambda x: -x[1]):
        pct = count / max(total_actions, 1) * 100
        print(f"    {act:<12}: {count:3d} ({pct:5.1f}%)")

    if reasoning_samples:
        print(f"\n  Sample Reasoning (first episode steps):")
        for s in reasoning_samples[:3]:
            print(f"    Step {s['step']}: CPU={s['cpu']:.1f}% -> {s['action']} PID {s['target']}")
            print(f"      Thought: {s['reasoning'][:120]}...")

    print(f"{'='*80}\n")

    return {
        "cost": total_cost,
        "avg_reward": total_reward / MAX_STEPS,
        "avg_cpu": avg_cpu,
        "kill_rate": kill_rate,
        "soft_action_ratio": soft_pct / 100,
        "sla_violations": total_violations["sla_violations"],
        "violations": total_violations,
        "action_counts": action_counts,
        "reasoning_samples": reasoning_samples,
    }


# ============================================================
# HEURISTIC BASELINE (for comparison)
# ============================================================

def heuristic_policy(obs) -> Action:
    """Simple heuristic baseline for benchmarking."""
    if not obs.processes:
        return Action(action_type="SCHEDULE")

    cpu = obs.cpu_usage
    by_cpu = sorted(obs.processes, key=lambda p: p.cpu, reverse=True)
    liars = [p for p in obs.processes if p.strategy in ("liar", "adversarial")]
    starved = [p for p in obs.processes if p.wait_time > 10]

    if cpu > 95 and by_cpu:
        return Action(action_type="KILL", target_pid=by_cpu[0].pid)
    if cpu > 85 and liars:
        return Action(action_type="THROTTLE", target_pid=liars[0].pid, throttle_percent=0.5)
    if cpu > 85 and by_cpu:
        return Action(action_type="THROTTLE", target_pid=by_cpu[0].pid, throttle_percent=0.5)
    if starved:
        return Action(action_type="REALLOCATE", target_pid=starved[0].pid)
    if cpu < 30:
        return Action(action_type="SCHEDULE")
    return Action(action_type="SCHEDULE")


def run_heuristic_episode(task: str) -> dict:
    """Run a full episode with heuristic policy."""
    env = AdaptiveOSEnv(task=task)
    obs = env.reset()

    total_cost = 0
    total_reward = 0
    cpu_history = []
    action_counts = {"SCHEDULE": 0, "KILL": 0, "PRIORITIZE": 0,
                     "THROTTLE": 0, "DELAY": 0, "REALLOCATE": 0}
    total_violations = {"sla_violations": 0, "starvation_count": 0, "unfair_allocations": 0}

    for step in range(MAX_STEPS):
        action = heuristic_policy(obs)
        action_counts[action.action_type] = action_counts.get(action.action_type, 0) + 1
        obs, reward, done, _ = env.step(action)
        total_cost += obs.cost
        total_reward += reward.value
        cpu_history.append(obs.cpu_usage)
        for key in total_violations:
            total_violations[key] += obs.violations.get(key, 0)
        if done:
            break

    total_actions = sum(action_counts.values())
    return {
        "cost": total_cost,
        "avg_reward": total_reward / MAX_STEPS,
        "avg_cpu": np.mean(cpu_history) if cpu_history else 0,
        "kill_rate": action_counts["KILL"] / max(total_actions, 1),
        "soft_action_ratio": (action_counts["THROTTLE"] + action_counts["DELAY"] +
                              action_counts["REALLOCATE"]) / max(total_actions, 1),
        "sla_violations": total_violations["sla_violations"],
        "violations": total_violations,
        "action_counts": action_counts,
    }


# ============================================================
# MODES
# ============================================================

def benchmark_mode(model, tokenizer):
    """Benchmark LLM agent vs heuristic baseline."""
    print("\n" + "=" * 80)
    print("BENCHMARK: LLM Agent vs Heuristic Baseline")
    print("=" * 80 + "\n")

    tasks = ["easy", "medium", "hard"]

    print(f"{'Task':<10} | {'LLM Cost':<10} | {'Heur Cost':<10} | {'Improvement':<12} | "
          f"{'LLM SLA':<8} | {'Heur SLA':<8} | {'Winner':<8}")
    print("-" * 85)

    results = {}
    for task in tasks:
        llm_metrics = run_llm_episode(task, model, tokenizer, show_reasoning=False, show_auditor=False)
        heur_metrics = run_heuristic_episode(task)

        cost_imp = ((heur_metrics["cost"] - llm_metrics["cost"]) /
                    max(heur_metrics["cost"], 0.01)) * 100
        winner = "LLM" if cost_imp > 0 else "HEUR"

        print(f"{task.upper():<10} | ${llm_metrics['cost']:<9.2f} | ${heur_metrics['cost']:<9.2f} | "
              f"{cost_imp:>+10.1f}% | "
              f"{llm_metrics['sla_violations']:<8} | {heur_metrics['sla_violations']:<8} | "
              f"{winner:<8}")

        results[task] = {
            "llm": llm_metrics,
            "heuristic": heur_metrics,
            "cost_improvement": cost_imp,
        }

    print("-" * 85)
    avg_imp = np.mean([r["cost_improvement"] for r in results.values()])
    print(f"\nAverage cost improvement: {avg_imp:+.1f}%")

    if avg_imp > 20:
        print("VERDICT: STRONG LLM DOMINANCE")
    elif avg_imp > 5:
        print("VERDICT: LLM ADVANTAGE")
    elif avg_imp > -5:
        print("VERDICT: COMPARABLE")
    else:
        print("VERDICT: HEURISTIC BETTER (more training needed)")

    return results


def whatif_mode(model, tokenizer, malicious_pct: int = 30):
    """What-if adversarial analysis."""
    print("\n" + "=" * 80)
    print(f"WHAT-IF ANALYSIS: {malicious_pct}% Malicious Agents")
    print("=" * 80)

    print("\n--- HEURISTIC under adversarial pressure ---")
    heur = run_heuristic_episode("hard")

    print("--- LLM AGENT under adversarial pressure ---")
    llm = run_llm_episode("hard", model, tokenizer, show_reasoning=True, show_auditor=True)

    cost_imp = ((heur["cost"] - llm["cost"]) / max(heur["cost"], 0.01)) * 100
    heur_v = sum(heur["violations"].values())
    llm_v = sum(llm["violations"].values())
    viol_imp = ((heur_v - llm_v) / max(heur_v, 1)) * 100

    print("\n" + "=" * 80)
    print("WHAT-IF RESULTS")
    print("=" * 80)
    print(f"\n  Heuristic:  Cost=${heur['cost']:.2f}  Violations={heur_v}  "
          f"{'COLLAPSED' if heur_v > 30 else 'UNSTABLE'}")
    print(f"  LLM Agent:  Cost=${llm['cost']:.2f}  Violations={llm_v}  "
          f"{'STABLE' if llm_v < 15 else 'MANAGING'}")
    print(f"\n  Cost improvement: {cost_imp:+.1f}%")
    print(f"  Violation reduction: {viol_imp:+.1f}%")

    print(f"\n  KEY: The LLM reasons about deception and adapts.")
    print(f"  It explains WHY it throttles liars instead of blindly following rules.")
    print("=" * 80 + "\n")


def demo_mode(model, tokenizer):
    """Full demo: show LLM reasoning on all difficulties."""
    print("\n" + "=" * 80)
    print("MACOS: Multi-Agent Compute OS - LLM Agent Demo")
    print("An LLM trained with GRPO to govern multi-tenant compute resources")
    print("=" * 80 + "\n")

    for task in ["easy", "medium", "hard"]:
        print(f"\n{'#' * 80}")
        print(f"# DIFFICULTY: {task.upper()}")
        print(f"{'#' * 80}")

        print("\n--- LLM AGENT (with reasoning) ---")
        llm_metrics = run_llm_episode(task, model, tokenizer,
                                      show_reasoning=True, show_auditor=True)

        print("\n--- HEURISTIC BASELINE ---")
        heur_metrics = run_heuristic_episode(task)

        cost_imp = ((heur_metrics["cost"] - llm_metrics["cost"]) /
                    max(heur_metrics["cost"], 0.01)) * 100

        print(f"\n  COMPARISON ({task.upper()}):")
        print(f"    LLM Cost:  ${llm_metrics['cost']:.2f}  |  Heuristic: ${heur_metrics['cost']:.2f}  |  {cost_imp:+.1f}%")
        print(f"    LLM SLA:   {llm_metrics['sla_violations']}  |  Heuristic: {heur_metrics['sla_violations']}")
        print(f"    LLM Soft%: {llm_metrics['soft_action_ratio']*100:.1f}%  |  Heuristic: {heur_metrics['soft_action_ratio']*100:.1f}%")


def quick_demo(model, tokenizer):
    """Quick demo: EASY difficulty only (for fast testing)."""
    print("\n" + "=" * 80)
    print("MACOS: Multi-Agent Compute OS - QUICK DEMO (EASY only)")
    print("=" * 80 + "\n")

    task = "easy"
    print(f"{'#' * 80}")
    print(f"# DIFFICULTY: {task.upper()}")
    print(f"{'#' * 80}")

    print("\n--- LLM AGENT (with reasoning) ---")
    llm_metrics = run_llm_episode(task, model, tokenizer,
                                  show_reasoning=True, show_auditor=True)

    print("\n--- HEURISTIC BASELINE ---")
    heur_metrics = run_heuristic_episode(task)

    cost_imp = ((heur_metrics["cost"] - llm_metrics["cost"]) /
                max(heur_metrics["cost"], 0.01)) * 100

    print(f"\n{'='*80}")
    print(f"COMPARISON ({task.upper()}):")
    print(f"  LLM Cost:  ${llm_metrics['cost']:.2f}  |  Heuristic: ${heur_metrics['cost']:.2f}  |  {cost_imp:+.1f}%")
    print(f"  LLM SLA:   {llm_metrics['sla_violations']}  |  Heuristic: {heur_metrics['sla_violations']}")
    print(f"  LLM Soft%: {llm_metrics['soft_action_ratio']*100:.1f}%  |  Heuristic: {heur_metrics['soft_action_ratio']*100:.1f}%")
    print(f"{'='*80}\n")


def main():
    parser = argparse.ArgumentParser(description="MACOS LLM Inference")
    parser.add_argument("--model", type=str, default="macos-llm-grpo",
                        help="Path to trained model or HF model name")
    parser.add_argument("--mode", choices=["demo", "benchmark", "whatif", "quick"],
                        default="demo", help="Execution mode (quick = EASY only)")
    parser.add_argument("--malicious", type=int, default=30,
                        help="Malicious agent percentage for what-if mode")
    args = parser.parse_args()

    model, tokenizer = load_llm(args.model)

    if args.mode == "benchmark":
        benchmark_mode(model, tokenizer)
    elif args.mode == "whatif":
        whatif_mode(model, tokenizer, args.malicious)
    elif args.mode == "quick":
        quick_demo(model, tokenizer)
    else:
        demo_mode(model, tokenizer)


if __name__ == "__main__":
    main()
